from django.db import models
from django.contrib.auth.models import User


class Booking(models.Model):
TABLE_CHOICES = [(i, f"Table {i}") for i in range(1, 21)]


user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bookings')
table_number = models.PositiveSmallIntegerField(choices=TABLE_CHOICES)
number_of_people = models.PositiveSmallIntegerField()
booking_date = models.DateField()
booking_time = models.TimeField()
special_requests = models.TextField(blank=True)
created_at = models.DateTimeField(auto_now_add=True)
updated_at = models.DateTimeField(auto_now=True)


class Meta:
ordering = ['-booking_date', '-booking_time']


def __str__(self):
return f"Booking {self.id} by {self.user.username} - Table {self.table_number} on {self.booking_date} {self.booking_time}"