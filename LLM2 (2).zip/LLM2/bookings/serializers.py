from rest_framework import serializers
from .models import Booking


class BookingSerializer(serializers.ModelSerializer):
user = serializers.ReadOnlyField(source='user.username')


class Meta:
model = Booking
fields = ['id', 'user', 'table_number', 'number_of_people', 'booking_date', 'booking_time', 'special_requests', 'created_at', 'updated_at']